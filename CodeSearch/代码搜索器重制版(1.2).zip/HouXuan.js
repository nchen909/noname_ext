// 对样式操作
var setClass = {
	hasClass: function(elements,cName){	// 判断是否含有某个class
		if(elements.className.match(new RegExp( "(\\s|^)" + cName + "(\\s|$)") ))
			return true;
		else
			return false;
	},
	addClass: function(elements,cName){	// 添加class
		if( !this.hasClass( elements,cName ) ){ 
			elements.className += " " + cName; 
		};
	},
	removeClass: function(elements,cName){	// 移除某个class
		if( this.hasClass( elements,cName ) ){ 
			elements.className = elements.className.replace( new RegExp( "(\\s|^)" + cName + "(\\s|$)" )," " ); 
		}
	}
}

var Bind = function(This){
	//return function(){
		This.init();
	//}
}

AutoComplete=function (input,auto,arr) {
	this.obj =input;
	//输入框
	this.autoObj = auto;
	this.search_value = "";	//当前的搜索输入值
	this.index = -1;		//当前选中的DIV的索引
	this.value_arr = arr;	//数据库中供检索的值 不包含重复值
}

AutoComplete.prototype = {
	// 初始化
	init: function(){
		var This = this;
		setClass.removeClass(This.autoObj,"hidden");
		//显示
		this.autoObj.style.left = this.obj.offsetLeft + "px";
		this.autoObj.style.top = this.obj.offsetTop + this.obj.offsetHeight + "px";
	},
	//删除自动完成需要的所有DIV
	deleteDIV: function(){
		while(this.autoObj.hasChildNodes()){
			this.autoObj.removeChild(this.autoObj.firstChild);
		}
		//移除div的子节点
		setClass.addClass(this.autoObj,"hidden");
		//隐藏
	},
	autoOnmouseover: function(index){
		if(index != this.index){
			setClass.addClass(this.autoObj.children[index],"on");
			setClass.removeClass(this.autoObj.children[this.index],"on");
			this.index = index;
		}
	},
	setValue: function(This){
		return function(){
			This.obj.value = this.seq;
			//alert(this)
			setClass.addClass(This.autoObj,"hidden");
			Queding();
		}
	},
	// 响应键盘
	pressKey: function(event){
	//老板，换碟
		var code = event.keyCode;
		var length = this.autoObj.children.length;
		//length是指div
		if(code == 38){		//↑
			setClass.removeClass(this.autoObj.children[this.index],"on");
			this.index--;
			if(this.index < 0){
				this.index = length - 1;
			}
			setClass.addClass(this.autoObj.children[this.index],"on");
			this.obj.value = this.autoObj.children[this.index].seq;
		}else if(code == 40){	//↓
			setClass.removeClass(this.autoObj.children[this.index],"on");
			this.index++;
			if(this.index > length-1){
				this.index = 0;
			}
			setClass.addClass(this.autoObj.children[this.index],"on");
			this.obj.value = this.autoObj.children[this.index].seq;
		    }else{  //回车
		    if(code===13){
			this.obj.value = this.autoObj.children[this.index].seq;
			setClass.addClass(this.autoObj,"hidden");
			this.index = -1;
			}
		}
	},
	// 程序入口，重要部分，每次输入运行此函数
	start: function(event){
	
		event = event || window.event;
		var code = event.keyCode;
		var This = this;
		//enter回车键
		/*回车键有两个作用,一是确认输入的执行命令,二是在文字处理中起换行的作用*/
		//up arrow 上方向键
		//down arrow 下方向键
		if(code !== 13 && code !== 38 && code !== 40){
			this.init();
			this.deleteDIV();
			//清除
			this.search_value = this.obj.value;
			//输入的内容
			var valueArr = this.value_arr.uniqueOnly();
			
			//去掉前后空格不能为空
			if(this.obj.value.replace(/(^\s*)|(\s*$)/g,"") == (""||null)||this.obj.value==""||null) return;	
			//判断数组中是否含有输入的关键字			
			var reg=this.obj.value.toLowerCase();
			
			var div_index = 0;	//记录匹配索引个数
			for (var i = 0; i < valueArr.length; i++) {
				if(valueArr[i].toLowerCase().indexOf(reg)!==-1){
					var div = document.createElement("div");
					div.className = "auto_out";
					//div.className = "auto_out on";
					div.seq = valueArr[i];
					div.index = div_index;
					var colorText=valueArr[i].slice(valueArr[i].toLowerCase().indexOf(reg),valueArr[i].toLowerCase().indexOf(reg)+reg.length);					
					var restText=valueArr[i].slice(0,valueArr[i].toLowerCase().indexOf(reg));
					var restText2=valueArr[i].slice(valueArr[i].toLowerCase().indexOf(reg)+reg.length);
					//div.innerHTML = valueArr[i].replace(reg,"<strong>$1</strong>");
					div.innerHTML=restText+"<font color=#f00>"+colorText+"</font>"+restText2;
					
					this.autoObj.appendChild(div);
					setClass.removeClass(this.autoObj,"hidden");
					div_index++;
									   
				   if(div_index == 1) {
						setClass.addClass(this.autoObj.firstChild,"on");
						this.index = 0;
						//div_index=0;
					}
					
					div.onmouseover = function(){
						This.autoOnmouseover(this.index);
					}
					div.onclick = this.setValue(This);
				}
			}
			/*
			var child="";
			for(var i=0;i<this.autoObj.childNodes .length;i++){
			child+=this.autoObj.childNodes[i].className+" "+this.autoObj.childNodes[i].innerHTML+"\n";
			}
			
			alert(child)
			*/
		} else{
		//this.pressKey(event,reg);
		}
	    Bind(This);
	}
}