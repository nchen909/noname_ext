game.import("extension",function(lib,game,ui,get,ai,_status){return {name:"代码搜索器重制版",content:function (config,pack){

String.prototype.replaceAll = function(from,to){
	var str = "";
	var pull=this;
while(pull.indexOf(from)!==-1){
    var arr=[];
    for(var i=0;i<pull .length;i++) arr.push(pull[i]);
    var newStr=arr.splice(0,pull.indexOf(from)+from.length).join("");
    str+=newStr.slice(0,newStr.length-from.length)+to;
    pull=arr.join("");
}
	return str+ pull;
};
// 数组去重
Array.prototype.uniqueOnly = function(){
	this.sort();
	var res = [];
	var json = {};
	for (var i = 0; i < this.length; i++) {
		if(!json[this[i]]){
			res.push(this[i]);
			json[this[i]] = 1;
		}
	}
	return res;
}			
            var url=lib.assetURL+'extension/代码搜索器重制版';
            lib.init.js(url,'clipboard',function(){
            //复制进剪切板还要引用个clipboard.js，我**你个大**，垃圾document.execCommand
            var clipboard = new ClipboardJS('.cxyFindCode_showText_viewBody_title_copy');
        	lib.init.js(url,'game.cxyFindCode',function(){        	
        	toCxyFindCode(lib,game,ui,get,ai,_status);
        	//alert("成功");
        	/*
        	第一次载入扩展会报错
        	不知道为什么
        	*/
        	});
        	});
			},
			precontent:function(){
                var link = document.createElement("link");
				link.href = lib.assetURL + "extension/代码搜索器重制版/"+(lib.config.extension_代码搜索器重制版_cxyTheme||"extension")+".css";
				link.type = "text/css";
				link.rel = "stylesheet";
				document.getElementsByTagName("head")[0].appendChild(link);
				
				var link2 = document.createElement("link");
				link2.href = lib.assetURL + "extension/代码搜索器重制版/auto.css";
				link2.type = "text/css";
				link2.rel = "stylesheet";
				document.getElementsByTagName("head")[0].appendChild(link2);
				
				game.cxySetCodeColor = function(fileName){
					link.setAttribute("href",lib.assetURL + "extension/代码搜索器重制版/"+fileName+".css");
				};
			
        	
        	
			},
			config: {
			    edter: {
					name:"原作者：<font color=#ff4a86>橙续缘</font>",
					clear: true,
				},
				redo: {
					name:"<font color=red>搜索结果</font>",
					clear: true,
					onclick: function(){
					if(game.getExtensionConfig("代码搜索器重制版","redoNum")){
	                game.cxyFindCode.onclicked(game.getExtensionConfig("代码搜索器重制版","redoNum"),game.getExtensionConfig("代码搜索器重制版","redoResult"));	
	                }		
					},
				},
				cxyFind: {
					name:"<font color=red>按描述搜索</font>",
					clear: true,
					onclick: function(){
					game.cxyFindCode.onclicked();					
					},
				},
				cxyFind1: {
					name:"<font color=#6df95b>按名字搜索</font>",
					clear: true,
					onclick: function(){
					game.cxyFindCode.onclicked(2);
					},
				},
				cxyFind2: {
					name:"<font color=#6df95b>按武将搜索</font>",
					clear: true,
					onclick: function(){
					game.cxyFindCode.onclicked(3);
					},
				},
				// cxyScroll: {
					// name:"下滑助手",
					// init: false,
					// intro:"若存在无法下滑问题，可开启下滑助手",
				// },
				cxyTheme: {
					name:"主题颜色",
					init:'skin0',
					item: {
						skin0:'黑夜',
						// extension:'白昼',
						//CS:'测试',
					},
					onclick:function(item){
						game.saveConfig("extension_代码搜索器重制版_cxyTheme",item);
						game.cxySetCodeColor(lib.config.extension_代码搜索器重制版_cxyTheme);
					}
				},
				cxySimilar: {
				/*
					name:"设置相同数",
					intro:"设置显示搜索结果的最低匹配多少个字",
				*/
				    name:"设置相似度",
					intro:"设置显示搜索结果的最低相似度",			
					item:{
						"1":"1",
						"0.9":"0.9",
						"0.8":"0.8",
						"0.7":"0.7",
						"0.6":"0.6",
						"0.5":"0.5",
					},
					init: '0.6',
					/*
					nopointer:true,
					clear:true,
					onclick:function(){
					var p=prompt("设置显示搜索结果的最低匹配多少个字\n请输入有效数字，负数为全部匹配，0为单个全部匹配","");
                    if(p!==""&&p!==null&&typeof p==="number"){
				    game.saveConfig("extension_代码搜索器重制版_cxySimilar",p);
						}
						else if(p!="") alert("无效数字！")
					}
					*/
				},
				
				
			},
			editable:false,
		}
	}
)