var toCxyFindCode=function (lib,game,ui,get,ai,_status){
game.cxyFindCode = {

/*
game.cxyFindCode.onclicked(1);
1 描述
2 名字
if(numberMode==1)
*/
onclicked:function(numberMode,redoResult){
// 对样式操作
var setClass = {
	hasClass: function(elements,cName){	// 判断是否含有某个class
		if(elements.className.match(new RegExp( "(\\s|^)" + cName + "(\\s|$)") ))
			return true;
		else
			return false;
	},
	addClass: function(elements,cName){	// 添加class
		if( !this.hasClass( elements,cName ) ){ 
			elements.className += " " + cName; 
		};
	},
	removeClass: function(elements,cName){	// 移除某个class
		if( this.hasClass( elements,cName ) ){ 
			elements.className = elements.className.replace( new RegExp( "(\\s|^)" + cName + "(\\s|$)" )," " ); 
		}
	}
}

var Bind = function(This){
	//return function(){
		This.init();
	//}
}

AutoComplete=function (input,auto,arr) {
	this.obj =input;
	//输入框
	this.autoObj = auto;
	this.search_value = "";	//当前的搜索输入值
	this.index = -1;		//当前选中的DIV的索引
	this.value_arr = arr;	//数据库中供检索的值 不包含重复值
}

AutoComplete.prototype = {
	// 初始化
	init: function(){
		var This = this;
		setClass.removeClass(This.autoObj,"hidden");
		//显示
		this.autoObj.style.left = this.obj.offsetLeft + "px";
		this.autoObj.style.top = this.obj.offsetTop + this.obj.offsetHeight + "px";
	},
	//删除自动完成需要的所有DIV
	deleteDIV: function(){
		while(this.autoObj.hasChildNodes()){
			this.autoObj.removeChild(this.autoObj.firstChild);
		}
		//移除div的子节点
		setClass.addClass(this.autoObj,"hidden");
		//隐藏
	},
	autoOnmouseover: function(index){
		if(index != this.index){
			setClass.addClass(this.autoObj.children[index],"on");
			setClass.removeClass(this.autoObj.children[this.index],"on");
			this.index = index;
		}
	},
	setValue: function(This){
		return function(){
			This.obj.value = this.seq;
			//alert(this)
			setClass.addClass(This.autoObj,"hidden");
			Queding();
		}
	},
	// 响应键盘
	pressKey: function(event){
	//老板，换碟
		var code = event.keyCode;
		var length = this.autoObj.children.length;
		//length是指div
		if(code == 38){		//↑
			setClass.removeClass(this.autoObj.children[this.index],"on");
			this.index--;
			if(this.index < 0){
				this.index = length - 1;
			}
			setClass.addClass(this.autoObj.children[this.index],"on");
			this.obj.value = this.autoObj.children[this.index].seq;
		}else if(code == 40){	//↓
			setClass.removeClass(this.autoObj.children[this.index],"on");
			this.index++;
			if(this.index > length-1){
				this.index = 0;
			}
			setClass.addClass(this.autoObj.children[this.index],"on");
			this.obj.value = this.autoObj.children[this.index].seq;
		    }else{  //回车
		    if(code===13){
			this.obj.value = this.autoObj.children[this.index].seq;
			setClass.addClass(this.autoObj,"hidden");
			this.index = -1;
			}
		}
	},
	// 程序入口，重要部分，每次输入运行此函数
	start: function(event){
	
		event = event || window.event;
		var code = event.keyCode;
		var This = this;
		//enter回车键
		/*回车键有两个作用,一是确认输入的执行命令,二是在文字处理中起换行的作用*/
		//up arrow 上方向键
		//down arrow 下方向键
		if(code !== 13 && code !== 38 && code !== 40){
			this.init();
			this.deleteDIV();
			//清除
			this.search_value = this.obj.value;
			//输入的内容
			var valueArr = this.value_arr.uniqueOnly();
			
			//去掉前后空格不能为空
			if(this.obj.value.replace(/(^\s*)|(\s*$)/g,"") == (""||null)||this.obj.value==""||null) return;	
			//判断数组中是否含有输入的关键字			
			var reg=this.obj.value.toLowerCase();
			
			var div_index = 0;	//记录匹配索引个数
			for (var i = 0; i < valueArr.length; i++) {
				if(valueArr[i].toLowerCase().indexOf(reg)!==-1){
					var div = document.createElement("div");
					div.className = "auto_out";
					//div.className = "auto_out on";
					div.seq = valueArr[i];
					div.index = div_index;
					var colorText=valueArr[i].slice(valueArr[i].toLowerCase().indexOf(reg),valueArr[i].toLowerCase().indexOf(reg)+reg.length);					
					var restText=valueArr[i].slice(0,valueArr[i].toLowerCase().indexOf(reg));
					var restText2=valueArr[i].slice(valueArr[i].toLowerCase().indexOf(reg)+reg.length);
					//div.innerHTML = valueArr[i].replace(reg,"<strong>$1</strong>");
					div.innerHTML=restText+"<font color=#f00>"+colorText+"</font>"+restText2;
					
					this.autoObj.appendChild(div);
					setClass.removeClass(this.autoObj,"hidden");
					div_index++;
									   
				   if(div_index == 1) {
						setClass.addClass(this.autoObj.firstChild,"on");
						this.index = 0;
						//div_index=0;
					}
					
					div.onmouseover = function(){
						This.autoOnmouseover(this.index);
					}
					div.onclick = this.setValue(This);
				}
			}
			/*
			var child="";
			for(var i=0;i<this.autoObj.childNodes .length;i++){
			child+=this.autoObj.childNodes[i].className+" "+this.autoObj.childNodes[i].innerHTML+"\n";
			}
			
			alert(child)
			*/
		} else{
		//this.pressKey(event,reg);
		}
	    Bind(This);
	}
}
/*
var url=lib.assetURL+'extension/代码搜索器重制版';
lib.init.js(url,'HouXuan',function(){
//HouXuan(HouXuannow);
//HouXuan(lib,game,ui,get,ai,_status);
begin();
});
*/
//function begin (numberMode){
var historySearch=game.getExtensionConfig("代码搜索器重制版","historySearch")||[];
if(historySearch&&historySearch.length>5){
historySearch.length=5;
game.saveExtensionConfig("代码搜索器重制版","historySearch",historySearch);
}

var theWholeSkillName=[];
for(var i in lib.skill) if(lib.skill[i]!={}) theWholeSkillName.add(lib.translate[i]||i);
var theWholeCharacterSkill={};
var theWholeCharacterName=[];
for(var i in lib.character){
theWholeCharacterName.add(lib.translate[i]||i);
if(lib.character[i][3]){
for(var j=0;j<lib.character[i][3] .length;j++){
theWholeCharacterSkill[lib.character[i][3][j]]=i;
}
}
}
//alert(CircularJSON.stringify(theWholeCharacterSkill))
//try{
//try catch影响性能
// 对样式操作
						if(!numberMode) numberMode=1;
						game.saveExtensionConfig("代码搜索器重制版","redoNum",numberMode);
							function cxyShowText(title,info,see){
							//title是[技能名+|+英文名]
							//info是处理后的描述或代码
							
								var view = ui.create.div(".cxyFindCode_showText");								
								var viewBody = ui.create.div(".cxyFindCode_showText_viewBody");								
								var viewComps = {
									title: ui.create.div(".cxyFindCode_showText_viewBody_title"),
									//text: oInput,
									text: ui.create.div(".cxyFindCode_showText_viewBody_text",info||""),
								};
								
								//alert(viewComps.text.innerHTML)	 污染							
								var viewTitleComps = {
								//已阅
									back: ui.create.div(".cxyFindCode_showText_viewBody_title_back","已阅"),
								//复制
									copy: ui.create.div(".cxyFindCode_showText_viewBody_title_copy","复制"),
									//copy: oInput,
									//text: oInput,
								    //text: ui.create.div(".cxyFindCode_showText_viewBody_title_text",title||""),									
								};
								viewTitleComps.copy.dataset.clipboardText=see;
								viewComps.text.setAttribute("contenteditable",false);
								//可编辑
								viewTitleComps.back.addEventListener("click",function(){
									document.getElementById("cxyFindCode").removeChild(view);
								});
								/*
								viewTitleComps.copy.addEventListener("click",function(){
                               // var oInput = document.getElementsByClassName("cxyFindCode_showText_viewBody_title_text");
                                oInput.select(); //选取内容
                                document.execCommand("Copy"); //执行浏览器复制命令  
								});
								*/
								//复制
								for(var i in viewTitleComps){
									viewComps.title.appendChild(viewTitleComps[i]);
								}
								for(var i in viewComps){
									viewBody.appendChild(viewComps[i]);
								}
								view.appendChild(viewBody);
								if(lib.config.extension_代码搜索器重制版_cxyScroll){
								//上下滑动事件
									var viewScroll = ui.create.div(".cxyFindCode_showText_viewScroll");
									var viewScrollComps = {
										toUp: ui.create.div(".cxyFindCode_showText_viewScroll_toUp","上滑"),
										toDown: ui.create.div(".cxyFindCode_showText_viewScroll_toDown","下滑"),
									};
									viewScrollComps.toUp.clicking = false;
									viewScrollComps.toUp.addEventListener("mousedown",function(){
										this.clicking = true;
										var that = this;
										var timer = function(time){
											if(!that.clicking)return ;
											if(time > 2) {
												viewComps.text.scrollTop = Math.max(0,viewComps.text.scrollTop-50);
											}
											setTimeout(function(){
												timer(time+1);
											},250);
										};
										timer(0);
									});
									//
									viewScrollComps.toUp.addEventListener("mouseup",function(){
										this.clicking = false;
										viewComps.text.scrollTop = Math.max(0,viewComps.text.scrollTop-50);
									});
									
									//当手指触摸屏幕时候触发，即使已经有一个手指放在屏幕上也会触发。
									viewScrollComps.toUp.addEventListener("touchstart",function(){
										this.clicking = true;
										var that = this;
										var timer = function(time){
											if(!that.clicking)return ;
											if(time > 2) {
												viewComps.text.scrollTop = Math.max(0,viewComps.text.scrollTop-50);
											}
											setTimeout(function(){
												timer(time+1);
											},250);
										};
										timer(0);
									});
									viewScrollComps.toUp.addEventListener("touchend",function(){
										this.clicking = false;
										viewComps.text.scrollTop = Math.max(0,viewComps.text.scrollTop-50);
									});
									viewScrollComps.toDown.clicking = false;
									viewScrollComps.toDown.addEventListener("mousedown",function(){
										this.clicking = true;
										var that = this;
										var timer = function(time){
											if(!that.clicking)return ;
											if(time > 2) {
												viewComps.text.scrollTop = Math.max(0,viewComps.text.scrollTop+50);
											}
											setTimeout(function(){
												timer(time+1);
											},250);
										};
										timer(0);
									});
									viewScrollComps.toDown.addEventListener("mouseup",function(){
										this.clicking = false;
										viewComps.text.scrollTop = Math.max(0,viewComps.text.scrollTop+50);
									});
									
									//当手指触摸屏幕时候触发，即使已经有一个手指放在屏幕上也会触发。
									viewScrollComps.toDown.addEventListener("touchstart",function(){
										this.clicking = true;
										var that = this;
										var timer = function(time){
											if(!that.clicking)return ;
											if(time > 2) {
												viewComps.text.scrollTop = Math.max(0,viewComps.text.scrollTop+50);
											}
											setTimeout(function(){
												timer(time+1);
											},250);
										};
										timer(0);
									});
									viewScrollComps.toDown.addEventListener("touchend",function(){
										this.clicking = false;
										viewComps.text.scrollTop = Math.max(0,viewComps.text.scrollTop+50);
									});
									for(var i in viewScrollComps){
										viewScroll.appendChild(viewScrollComps[i]);
									}
									view.appendChild(viewScroll);
								}
								document.getElementById("cxyFindCode").appendChild(view);
							};
							
							//var Windowbody = ui.create.div("#cxyFindCode");
							var body = ui.create.div("#cxyFindCode");
							//Windowbody.appendChild(body);
							//body.style.overflow="scroll";
							//body是整个框架
							var bodyComps = {
								title: ui.create.div("#cxyFindCode_title"),
								input: ui.create.div("#cxyFindCode_input"),
								result: ui.create.div("#cxyFindCode_result"),
							};
							if(lib.config.extension_代码搜索器重制版_cxyScroll) {
								bodyComps.result.id = "cxyFindCode_result2";
								bodyComps.scroll = ui.create.div("#cxyFindCode_scroll");
								var scrollComps = {
									toUp: ui.create.div("#cxyFindCode_scroll_toUp","上<br>滑"),
									toDown: ui.create.div("#cxyFindCode_scroll_toDown","下<br>滑"),
								};
								scrollComps.toUp.style["line-height"] = ((document.body.offsetHeight-95)*0.5 - 4)/2+"px";
								scrollComps.toDown.style["line-height"] = ((document.body.offsetHeight-95)*0.5 - 4)/2+"px";
								scrollComps.toUp.clicking = false;
								//某个鼠标按键按下
								scrollComps.toUp.addEventListener("mousedown",function(){
									this.clicking = true;
									var that = this;
									var timer = function(time){
										if(!that.clicking) return;
										if(time > 2) {
											bodyComps.result.scrollTop = Math.max(0,bodyComps.result.scrollTop-50);
										}
										setTimeout(function(){
											timer(time+1);
										},250);
									};
									timer(0);
								});
								//某个鼠标按键被松开
								scrollComps.toUp.addEventListener("mouseup",function(){
									this.clicking = false;
									bodyComps.result.scrollTop = Math.max(0,bodyComps.result.scrollTop-50);
								});
								
								//当手指触摸屏幕时候触发，即使已经有一个手指放在屏幕上也会触发。
								scrollComps.toUp.addEventListener("touchstart",function(){
									this.clicking = true;
									var that = this;
									var timer = function(time){
										if(!that.clicking)return ;
										if(time > 2) {
											bodyComps.result.scrollTop = Math.max(0,bodyComps.result.scrollTop-50);
										}
										setTimeout(function(){
											timer(time+1);
										},250);
									};
									timer(0);
								});
								scrollComps.toUp.addEventListener("touchend",function(){
									this.clicking = false;
									bodyComps.result.scrollTop = Math.max(0,bodyComps.result.scrollTop-50);
								});
								scrollComps.toDown.clicking = false;
								scrollComps.toDown.addEventListener("mousedown",function(){
									this.clicking = true;
									var that = this;
									var timer = function(time){
										if(!that.clicking)return ;
										if(time > 2) {
											bodyComps.result.scrollTop = Math.max(0,bodyComps.result.scrollTop+50);
										}
										setTimeout(function(){
											timer(time+1);
										},250);
									};
									timer(0);
								});
								scrollComps.toDown.addEventListener("mouseup",function(){
									this.clicking = false;
									bodyComps.result.scrollTop = Math.max(0,bodyComps.result.scrollTop+50);
								});
								
								//当手指触摸屏幕时候触发，即使已经有一个手指放在屏幕上也会触发。
								scrollComps.toDown.addEventListener("touchstart",function(){
									this.clicking = true;
									var that = this;
									var timer = function(time){
										if(!that.clicking)return ;
										if(time > 2) {
											bodyComps.result.scrollTop = Math.max(0,bodyComps.result.scrollTop+50);
										}
										setTimeout(function(){
											timer(time+1);
										},250);
									};
									timer(0);
								});
								scrollComps.toDown.addEventListener("touchend",function(){
									this.clicking = false;
									bodyComps.result.scrollTop = Math.max(0,bodyComps.result.scrollTop+50);
								});
								for(var i in scrollComps){
									bodyComps.scroll.appendChild(scrollComps[i]);
								}
							}
							if(numberMode==1){
							var titleComps = {
								back: ui.create.div("#cxyFindCode_title_back","返回"),
								text: ui.create.div("#cxyFindCode_title_text","按描述搜索"),
							};
							}
							if(numberMode==2){
							var titleComps = {
								back: ui.create.div("#cxyFindCode_title_back","返回"),
								text: ui.create.div("#cxyFindCode_title_text","按名字搜索"),
							};
							}
							if(numberMode==3){
							var titleComps = {
								back: ui.create.div("#cxyFindCode_title_back","返回"),
								text: ui.create.div("#cxyFindCode_title_text","按武将搜索"),
							};
							}
							var inputComps = {
								button: ui.create.div("#cxyFindCode_input_button","查找"),
								buttonBan: ui.create.div("#cxyFindCode_input_buttonBan"),
								textInput: ui.create.div("#cxyFindCode_input_textInput"),
							};
							/*
	<div class="wrap">
		<input type="text" id="input" class="auto-inp">
		
		<div class="auto hidden" id="auto">
			<div class="auto_out">1</div>
			<div class="auto_out">2</div>
		</div>
	</div>
							*/
							var div=ui.create.div(".auto.hidden#auto");
							var div1=ui.create.div(".auto_out");						
							var div2=ui.create.div(".auto_out");
							div.appendChild(div1);				
							div.appendChild(div2);				
							//var array = ["星野梦美"];
							if(numberMode==1) var array=game.getExtensionConfig("代码搜索器重制版","historySearch")||[];
							if(numberMode==2) var array=theWholeSkillName;							
							if(numberMode==3) var array=theWholeCharacterName;
							var textInput = document.createElement("input");
							
							//YH.addObjListener(textInput,"value",function(e){alert(99)});
							var autoComplete = new AutoComplete(textInput,div,array);
							textInput.addEventListener("keyup",function(event){
			                autoComplete.start(event);
	                    	});
							//textInput是搜索框
							textInput.type = "text";
							textInput.id = "cxyFindCode_input_textInput_input";
							if(numberMode==1) textInput.placeholder = "填写技能描述";
							if(numberMode==2) textInput.placeholder = "填写技能名字";
							if(numberMode==3) textInput.placeholder = "填写武将名字";
							//placeholder是搜索提示文字
							//元素获得焦点
							textInput.addEventListener("focus",function(){
								inputComps.textInput.style["border-bottom"] = "0.5px solid rgb(255,128,10)";
								//#ff800a黄色
							});
							
							//元素失去焦点
							textInput.addEventListener("blur",function(){
								inputComps.textInput.style["border-bottom"] = "0.5px solid rgb(180,180,180)";
								//#b4b4b4灰色
							});
							//某个键盘的键被按下
							textInput.addEventListener("keydown",function(){
								setTimeout(function(){
								//alert(textInput.value)
									if(textInput.value) inputComps.buttonBan.style.display = "none";
									else inputComps.buttonBan.style.display = "block";
								},100);
								//改变提示内容显示与否
							});
							inputComps.textInput.appendChild(textInput);
							inputComps.textInput.appendChild(div);
							
							titleComps.back.addEventListener("click",function(){
								document.getElementById("window").removeChild(body);
								delete lib.QuedingedPast;
							});
							inputComps.button.addEventListener("click",Queding);
							if(redoResult) Queding();
							function Queding(){
							textInput.value=redoResult||textInput.value;
							var info = textInput.value||redoResult;
							if(info===lib.QuedingedPast) return;
							if(!info) return; //没字就走
							lib.QuedingedPast=info;
							game.saveExtensionConfig("代码搜索器重制版","redoResult",info);
							/*
							    var QuedingedNum=0;
							    var set= window.setInterval(function(){
							    if(lib.TangLonged===true){
							    window.clearInterval(set);
							    alert(QuedingedNum/1000);
							    }
							    else QuedingedNum++;
							    },1);
							 */
							    autoComplete.deleteDIV();
								bodyComps.result.innerHTML = "";
								
								var newHistorySearch=game.getExtensionConfig("代码搜索器重制版","historySearch")||[];
								historySearch.remove(info);
								newHistorySearch.unshift(info);
								game.saveExtensionConfig("代码搜索器重制版","historySearch",newHistorySearch);
								
								var infos = game.cxyFindCode.find(info,numberMode);
								//alert(infos);
								/*
								排序
								*/
								var sortInfos = [] , max_similar = null;
								function objlen(obj){
									for(var i in obj){
										return true;
									}
									return false;
								};
								while(objlen(infos)) {
									for(var i in infos) {
										if(max_similar == null){
											max_similar = i;
										}
										else if(infos[i] > infos[max_similar]) {
											max_similar = i;
										}
									}
									sortInfos.push([max_similar,infos[max_similar]]);
									delete infos[max_similar];
									max_similar = null;
								};
								/*
									输出
								*/
								titleComps.text.innerHTML = "按描述搜索[共查询到 "+sortInfos.length+" 条结果]";
								function print(arr){
								//print函数把捜索到的每个结果：英文名+相似度，进行处理
									var tmp = ui.create.div(".cxyFindCode_result_tmp");
									var tmpComps = {
										lookCode: ui.create.div(".cxyFindCode_result_tmp_lookCode","查看代码"),
										lookInfo: ui.create.div(".cxyFindCode_result_tmp_lookInfo","查看描述"),
										textShow: ui.create.div(".cxyFindCode_result_tmp_textShow"),
									};
									tmpComps.lookCode.info = arr;									
									tmpComps.lookInfo.info = arr;
									tmpComps.lookInfo.str = info;
									
									//info是刚才搜索的
									/*
									for(var i in lib.character){
									if(lib.character[i][3].contains(arr[0])){
								    var characterName=i;
								    break;
								    }
									}
									此方法太浪费时间
									*/
									//alert(theWholeCharacterSkill[arr[0]])							
									var textShowComps = {
									//灵愈|lingyu
										skillname: ui.create.div(".cxyFindCode_result_tmp_textShow_skillname",lib.translate[arr[0]]+"|"+arr[0]),
										//characterName:ui.create.div(".cxyFindCode_result_tmp_textShow_characterName",""),
										//80%
										similar: ui.create.div(".cxyFindCode_result_tmp_textShow_similar",(arr[1]*100)+"%"),
									};
									
									if(theWholeCharacterSkill[arr[0]]){
									//alert(characterName)
									var translation=get.translation(theWholeCharacterSkill[arr[0]]);
									if(translation!="") theWholeCharacterSkill[arr[0]]=translation+"|"+theWholeCharacterSkill[arr[0]];
									textShowComps.characterName=ui.create.div(".cxyFindCode_result_tmp_textShow_characterName",theWholeCharacterSkill[arr[0]]);
									}
									/*
									if(tmpComps.characterName){
									tmpComps.characterName.addEventListener("click",function(){
									alert("误触")
									});
									}
									*/
									tmpComps.lookCode.addEventListener("click",function(){
										var skill = this.info[0];
										var title = "查看代码["+lib.translate[skill]+"|"+skill+"]";
										var skill_info = get.stringify(get.info(skill));
										var info = "";
										skill_info = skill_info.replaceAll(">","&gt;");
										skill_info = skill_info.replaceAll("<","&lt;");
										for(var i=0;i<skill_info.length;i++){
											if(skill_info.charCodeAt(i)==10){
												info += "<br>";
											}
											else if(skill_info.charCodeAt(i)==32){
												info += "&nbsp;"
											}
											else {
												info += skill_info[i];
											}
										}
										/*
											代码高亮
										*/
										function lightHight(info) {
											var Info = "<font class='cxyCode_red'>";
											var style = false , strnow = null;
											var specialCode = [
												"var","if","else","switch","case",
												"default","for","while","do","break",
												"continue","goto","undefined","Infinity",
												"function","return","&gt;",
												"&lt;",
											];
											for(var i=0;i<info.length;i++){
												if(info[i]=='<')style = true;
												if(style){
													Info += info[i];
													if(info[i]=='>')style = false;
													continue;
												}
												if(info[i]=='&'&&info.substr(i,6)=="&nbsp;"){
													Info+=info.substr(i,6);
													i += 5;
													continue;
												}
												if(info[i]=='\"' || info[i]=='\'') {
													if(strnow == null) {
														strnow = info[i];
														Info += "<font class='cxyCode_yellow'>"+info[i];
														continue;
													}
												}
												if(strnow){
													Info += info[i];
													if(info[i] == strnow){
														Info += "</font>";
														strnow = null;
													}
													continue;
												}
												var sc = false;
												for(var k=0;k<specialCode.length;k++){
													if(info.substr(i,specialCode[k].length)==specialCode[k]){
														Info += "<font class='cxyCode_oringe'>"+info.substr(i,specialCode[k].length)+"</font>";
														i += specialCode[k].length-1;
														sc = true;
														break;
													}
												}
												if(sc)continue;
												if(!/[A-Za-z0-9]/.test(info[i])){
													Info += "<font class='cxyCode_white'>"+info[i]+"</font>";
													continue;
												}
												Info += info[i];
											}
											Info+="</font>";
											return Info;
										};										
										cxyShowText(title,lightHight(info),skill_info);
									});
									tmpComps.lookInfo.addEventListener("click",function(){
									//alert("查看描述")
										var skill = this.info[0];
                                        //技能名
										var str = this.str;
										//输入的内容
										var title = "查看描述["+lib.translate[skill]+"|"+skill+"]";
										var info = lib.translate[skill+"_info"]||"" , lastPos = 0;
										//info是描述
										//alert("原：\n"+info)
										str = str.split(" ");
										var regTxet=info.match(/^<.+>$/)==null?[]:info.match(/^<.+>$/);
										var newInfo=info.split(/^<.+>$/);
										for(var num=0;i<newInfo .length;num++){
										lastPos = 0;
										for(var t=0;t<str.length;t++){
										//真：str[t]
											for(var i=0;i<str[t].length;i++){
											//str是数组，str[t]是字符串，lastPos是0											
												for(var k=lastPos;k<newInfo[num].length;k++){
												//str[t][i]是每个单词
													if(str[t][i]==newInfo[k]){
														newInfo = newInfo.substring(0,k)+"<font color=#f00>"+newInfo[k]+"</font>"+newInfo.substring(k+1,newInfo.length);
														//substring，与slice差不多
														lastPos = k+1;
														break;
													}
												}
											}									
											lastPos = 0;
											//以输入内容的每个单词为单位，把它们变红
										}
										newInfo[num]+=regTxet[num];
										}
										//alert("现：\n"+newInfo.join(""))
										cxyShowText(title,newInfo.join(""));
									});
									
									for(var i in textShowComps){
										tmpComps.textShow.appendChild(textShowComps[i]);
									}
									for(var i in tmpComps) {
										tmp.appendChild(tmpComps[i]);
									}
									bodyComps.result.appendChild(tmp);
								}
								//sortInfos[i][0]是技能，sortInfos[i][1]是相似度
								for(var i=0;i<sortInfos.length;i++){
									print(sortInfos[i]);
								}
							};
							//Queding完结
							for(var i in titleComps){
								bodyComps.title.appendChild(titleComps[i]);
								//返回 按描述搜索  左上角
							}
							for(var i in inputComps){
								bodyComps.input.appendChild(inputComps[i]);
								//查找 提示 查找底色  搜索框
							}
							for(var i in bodyComps){						
								body.appendChild(bodyComps[i]);								
							}
							//只是初始化
							//console.log(bodyComps.result.innerHTML)
							ui.window.appendChild(body);
						/*
						}
						catch(e){
						game.print(e);
						}
						*/				
						//};
					    },
				//similar+=game.cxyFindCode.compare(strs[k][0],info,strs[k][1]||"");
				//strs[k][0]是中文名，info是描述，strs[k][1]是英文名
					compare: function(str1,str2,arr){		
						var distence = Infinity , lenGap = str1.length - str2.length;
						//lenGap为中文名减去描述长度
						var perDis = [1,1];
						if(arr){
							arr = arr.split("&");
							//arr用&分隔
							for(var i=0;i<arr.length;i++){
							//str1是中文名
							//strk+="原中："+str1+"\n";					
							str1 = str1.replaceAll(arr[i],String.fromCharCode("A".charCodeAt(0)+i));						
							//strk+="现："+str1+"\n";
							//String.fromCharCode：可接受一个指定的 Unicode 值，然后返回一个字符串。
							//charCodeAt() 方法可返回指定位置的字符的 Unicode 编码。这个返回值是 0 - 65535 之间的整数。
							//依次+1相当于ABCDE……
							//str2描述
							//strk+="原描："+str2+"\n";
							str2 = str2.replaceAll(arr[i],String.fromCharCode("A".charCodeAt(0)+i));
							//strk+="现："+str2+"\n";
							//中文换成英文，这操作好迷
							}
							perDis = [0.5,1.5];
							//perDis变化
						}						
						for(var i=0;i<str2.length;i++){
						//重复描述次
							var tmpDis = Math.max(0,lenGap);
							//为描述减去中文名长度，至少0
							for(var k=0;k<Math.min(str1.length,str2.length);k++){
							//str1，是技能中文名
							//info是描述
							//其中小者
							//[A-Z]大写字母
							if(str1[k] != str2[k+i]) tmpDis+=(/[A-Z]/.test(str1[k])?perDis[1]:perDis[0]);
							//
							}
							//distence最开始是无限大
							if(tmpDis < distence) distence = tmpDis;
							lenGap++;
						}
						//骚操作好多，可恶呀
						//strk+=get.round((str1.length - distence)/str1.length,4)+"\n";
						return get.round((str1.length - distence)/str1.length,4);
						
					},
					//var infos = game.cxyFindCode.find(info,0.5);
					find: function(str,numberMode){
						var tmp = {};
						var num = lib.config.extension_代码搜索器重制版_cxySimilar||0.6;
						var strs = str.split(" ");
						//将输入的字符数以空格分隔						
						for(var i=0;i<strs.length;i++){
							strs[i] = strs[i].split("|");
						}
						//以|分为两部分
						//用|分隔strs
						//var renum=0
						//window.strk="";
						function BI(info) {					
							//info是描述
							if(!info||info=="") return;
							if(typeof info !== "string") return;
							var similar = 0;														
							for(var k=0;k<strs.length;k++){
							//strs是双数组
							similar+=game.cxyFindCode.compare(strs[k][0],info,strs[k][1]||"");
							/*
							if(renum<25){				
							str+="中文名："+strs[k][0]+"   ";
							str+="描述："+info+"   "
							str+="英文名："+strs[k][1]
							str+="相似值："+game.cxyFindCode.compare(strs[k][0],info,strs[k][1]||"")+"\n";
							renum++;
							}
							*/					
							//strs[k][0]是中文名，info是描述，strs[k][1]是中文名
							}
							similar = similar/strs.length;
							//假如输入了X Y，则X Y的匹配结果除以二即平均分
							
							if(similar>(num||0.6)){
								tmp[i] = get.round(similar,4);
							//tmp的属性为技能英文名，属性值为相似值
							//相似值为要求的字符串个数除以达到的字符串个数
							//
							}
						};
						//str+="返回值："+CircularJSON.stringify(tmp)+"\n"
						//KJ.try(strk);						
						if(numberMode==3){
						for(var i in lib.character){
						if(lib.character[i][3]&&lib.character[i][3].length){
						BI(lib.translate[i]||i);
						}
						}
						//alert(CircularJSON.stringify(tmp,null,2))
						if(tmp!={}){
						var newt={};
						for(var i in tmp){
						for(var j=0;j<lib.character[i][3] .length;j++){
						newt[lib.character[i][3][j]]=tmp[i];
						}
						}
						tmp=newt;
						}
						}
						else{
						for(var i in lib.skill){
						//对每个技能进行检索
							if(numberMode==1) var info = lib.translate[i+"_info"];
							if(numberMode==2) var info = lib.translate[i];
							BI(info);
                        }
                        }
						return tmp;
						//{"qtpz_aozun":1,"jyzongshi":1,"anguo":1,"sheying":1,"mengun":1,"huanxia":1,"yueren":1,"hslingjian_shijianhuisu_equip5":1,"gw_youer":1}
					    },
						};	
							
						}