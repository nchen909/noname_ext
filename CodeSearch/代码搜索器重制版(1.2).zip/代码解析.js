extension.css 白天
skin0.css 黑夜

代码搜索器相似值的实现主要是靠
game.cxyFindCode.find函数实现
game.cxyFindCode.find(str);
先讲两个关系：
相平：
最终概率为相平方各概率之和除以相平方个数
即平均分

相补：
每个相补方的概率为总概率的1/p（p为相补方个数）
最终概率为相补方各概率之和

以下分法的数量不限
str：要搜索的内容
str可以用空格隔开，也可以不用
eg:
A B
A与B相平

然后A和B或str都可以用|细分为
a|b
a与b相补

b还可以用&再分
x&y
x与y相补
其中

game.cxyFindCode = {
				//similar+=game.cxyFindCode.compare(strs[k][0],info,strs[k][1]||"");
				//strs[k][0]是中文名，info是描述，strs[k][1]是英文名
					compare: function(str1,str2,arr){		
						var distence = Infinity , lenGap = str1.length - str2.length;
						//lenGap为中文名减去描述长度
						var perDis = [1,1];
						if(arr){
							arr = arr.split("&");
							//arr用&分隔
							for(var i=0;i<arr.length;i++){
							//str1是中文名
							//strk+="原中："+str1+"\n";
							
							str1 = str1.replaceAll(arr[i],String.fromCharCode("A".charCodeAt(0)+i));
							
							//strk+="现："+str1+"\n";
							//String.fromCharCode：可接受一个指定的 Unicode 值，然后返回一个字符串。
							//charCodeAt() 方法可返回指定位置的字符的 Unicode 编码。这个返回值是 0 - 65535 之间的整数。
							//依次+1相当于ABCDE……
							//str2描述
							//strk+="原描："+str2+"\n";
							str2 = str2.replaceAll(arr[i],String.fromCharCode("A".charCodeAt(0)+i));
							//strk+="现："+str2+"\n";
							//中文换成英文，这操作好迷
							}
							perDis = [0.5,1.5];
							//perDis变化
						}
						
						for(var i=0;i<str2.length;i++){
						//重复描述次
							var tmpDis = Math.max(0,lenGap);
							//为描述减去中文名长度，至少0
							for(var k=0;k<Math.min(str1.length,str2.length);k++){
							//str1，是技能中文名
							//info是描述
							//其中小者
							//[A-Z]大写字母
							if(str1[k] != str2[k+i]) tmpDis+=(/[A-Z]/.test(str1[k])?perDis[1]:perDis[0]);
							//
							}
							//distence最开始是无限大
							if(tmpDis < distence) distence = tmpDis;
							lenGap++;
						}
						//骚操作好多，可恶呀
						//strk+=get.round((str1.length - distence)/str1.length,4)+"\n";
						return get.round((str1.length - distence)/str1.length,4);
						
					},
					//var infos = game.cxyFindCode.find(info,0.5);
					find: function(str,num){
						var tmp = {};
						num = lib.config.extension_代码搜索器_cxySimilar||0.6;
						var strs = str.split(" ");
						//将输入的字符数以空格分隔
						
						for(var i=0;i<strs.length;i++){
							strs[i] = strs[i].split("|");
						}
						//以|分为两部分
						//用|分隔strs
						//var renum=0
						//window.strk="";
						for(var i in lib.skill) {
						//对每个技能进行检索
							var info = lib.translate[i+"_info"];
							//info是描述
							if(!info||info=="") continue;
							if(typeof info !== "string") continue;
							var similar = 0;
														
							for(var k=0;k<strs.length;k++){
							//strs是双数组
							similar+=game.cxyFindCode.compare(strs[k][0],info,strs[k][1]||"");
							/*
							if(renum<25){				
							str+="中文名："+strs[k][0]+"   ";
							str+="描述："+info+"   "
							str+="英文名："+strs[k][1]
							str+="相似值："+game.cxyFindCode.compare(strs[k][0],info,strs[k][1]||"")+"\n";
							renum++;
							}
							*/					
							//strs[k][0]是中文名，info是描述，strs[k][1]是中文名
							}
							similar = similar/strs.length;
							//假如输入了X Y，则X Y的匹配结果除以二即平均分
							
							if(similar>(num||0.6)){
								tmp[i] = get.round(similar,4);
							//tmp的属性为技能英文名，属性值为相似值
							//相似值为要求的字符串个数除以达到的字符串个数
							//
							}
						}
						//str+="返回值："+CircularJSON.stringify(tmp)+"\n"
						//KJ.try(strk);
						return tmp;
						//{"qtpz_aozun":1,"jyzongshi":1,"anguo":1,"sheying":1,"mengun":1,"huanxia":1,"yueren":1,"hslingjian_shijianhuisu_equip5":1,"gw_youer":1}
					},
				};