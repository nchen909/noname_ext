game.import("extension", function(lib, game, ui, get, ai, _status) {
	game.removeExtension("武将卡牌搜索器", false);
	return {
		name: "全能搜索",
		editable: false,
		content: function(config, pack) {
			game.tujianBegin = function(dialog, close, val, manual) {
				var nodes = dialog.content.childNodes;
				while (dialog.content.hasChildNodes()) {
					dialog.content.removeChild(dialog.content.firstChild);
				}
				var result = val;
				if (result === "" || result === null || result === undefined) {
					result = "请输入名称";
					alert(result);
					return;
				}
				var Image = ui.background.style.backgroundImage;
				var list = ['相爱相杀', 'picture'].randomGet();
				ui.background.setBackgroundImage("extension/全能搜索/" + list + ".png");
				var back = false;
				var value = false;
				var name = [];
				for (var a in lib.character) {
					//if (lib.translate[a] == result) {     (这是精确搜索)
					//改为模糊搜索:
					if (lib.translate[a] && lib.translate[a].includes(result)) {
						name.push(a);
						value = true;
					}
				} //寻找武将
				if (value == false || name.length == 0) {
					//alert('找不到名为' + result + '的武将!');
					back = true;
				}
				//进一步
				funcs.for([name, 0, 'length'], function(i, name) {
					dialog.addSmall([
						[name[i]], 'character'
					]);
					var str = '';
					var character = lib.character[name[i]];
					if (!character) {
						return;
					} else {
						var allcharacter = lib.characterPack;
						var Packname;
						for (var b in allcharacter) {
							if (name[i] in allcharacter[b]) {
								Packname = lib.translate[b + '_character_config'];
								break;
							}
						}
						var skillstr = '';
						var char3 = character[3];
						funcs.for([char3, 0, char3.length], function(i, char3) {
							if (lib.translate[char3[i]]) {
								skillstr +=
									`<li onclick='
									this.nextElementSibling.style.display = this.nextElementSibling.style.display == "none" ? "" : "none";
									'>
									<font color="#21ffd8">[ ${lib.translate[char3[i]]} ]</font>
									<font color=#6df95b>[ ${char3[i]} ]</font>：${lib.translate[char3[i] + '_info']}
									</li>
									<li style="display: none; list-style-type: none;">
									<font color="#21ffd8">[ ${lib.translate[char3[i]]} ] </font>技能代码：</br>
									<textarea cols="80" rows="35" readOnly="readOnly">${get.stringify(lib.skill[char3[i]])}</textarea>
									</li>`;
							}
						});
						str += '<br><span class="bluetext">武将信息</span>：' + get.characterIntro(name[i]) +
							'<br><span class="bluetext">所在武将包</span>：' + Packname +
							'<br><span class="bluetext">武将名称</span> ：' + lib.translate[name[i]] + '<font color=#6df95b>[' + name[i] +
							']</font><br><span class="bluetext">武将性别</span>：' + lib.translate[
								character[0]] + '<br><span class="bluetext">武将势力</span>：' + lib.translate[character[1]] +
							'<br><span class="bluetext">体力上限</span>：' + character[2] + '<br><span class="bluetext">武将技能</span>：' +
							skillstr + '<br><br><br>';
					}
					dialog.addText('<div><div id="Cdetail" style="display:block; left:auto; text-align:left; ">' + str);
				});
				var back2 = false;
				value = false;
				name = [];
				for (var a in lib.card) {
					//if (lib.translate[a] == result) {     (这是精确搜索)
					//改为模糊搜索:
					if (lib.translate[a] && lib.translate[a].includes(result)) {
						name.add(a);
						value = true;
					}
				} //寻找卡牌
				if (value == false || name.length == 0) {
					//alert('找不到名为' + result + '的卡牌!');
					back2 = true;
				}
				//进一步
				funcs.for([name, 0, name.length], function(i, name) {
					dialog.addSmall([
						[name[i]], 'vcard'
					]);
					var str = '';
					var card = lib.card[name[i]];
					if (!card) {
						return;
					} else {
						var allcard = lib.cardPack;
						var Packname;
						for (var b in allcard) {
							var cardPack = lib.cardPack[b];
							funcs.for([cardPack, 0, cardPack.length], function(c, cardPack) {
								if (cardPack[c] == name[i]) {
									Packname = lib.translate[b + '_card_config'];
									return true;
								}
							});
						}
						//suit number name nature
						str +=
							`<br><span class="bluetext">卡牌名称</span> ${lib.translate[name[i]]}  </font><font color=#6df95b>[
							${name[i]} ]</font>
							<br><span class="bluetext">卡牌类别</span> ： ${lib.translate[lib.card[name[i]].type]}
							<br><span class="bluetext">卡牌效果</span>：${lib.translate[name[i] + '_info']}
							<br><span class="bluetext">所在卡牌包</span>：${Packname}`;
						if (lib.card[name[i]].derivation) {
							str += `<br><span class="bluetext">卡牌来源</span> ：${lib.translate[lib.card[name[i]].derivation]}`;
						}
						str +=
							`<br><span style="color:#6df95b" onclick='
							this.nextElementSibling.style.display = this.nextElementSibling.style.display == "none" ? "" : "none";
							'>
							点击查看/关闭${lib.translate[name[i]]}代码
							</span>
							<span style="display: none;">
							<br>
							<font color="#21ffd8">[ ${lib.translate[name[i]]} ] </font>卡牌代码：</br>
							<textarea cols="80" rows="40" readOnly="readOnly">${get.stringify(lib.card[name[i]])}</textarea>
							</span><br><br><br>`;
					}
					dialog.addText('<div><div id="Cdetail" style="display:block; left:auto; text-align:left; ">' + str);
				});
				if (back == true && back2 == true) {
					alert('没有符合条件的武将或卡牌!');
					var nodes = dialog.content.childNodes;
					funcs.for([nodes, nodes.length - 1, '>=', 0, '-1'], function(i, nodes) {
						dialog.content.removeChild(nodes[i]);
					});
				}
			};
		},
		precontent: function() {
			var layoutPath = lib.assetURL + 'extension/全能搜索';
			lib.init.css(layoutPath, 'extension');
			window.诗笺_manual = {
				show: function() {
					var Image = ui.background.style.backgroundImage;
					var manual = ui.create.div('.manual', manual);
					var menu = ui.create.div('.menu', manual);
					var input = menu.appendChild(document.createElement('input'));
					input.onkeydown = function(e) {
						if (e && e.keyCode == 13) {
							game.tujianBegin(content, close, input.value, manual);
							input.value = "";
						}
					};
					var search = ui.create.div('.search', menu);
					var close = ui.create.div('.close', menu);
					var oldDialog = _status.event.dialog;
					var dialog = ui.create.dialog();
					dialog.noImage = true;
					dialog.style.backgroundImage = "";

					var content = manual.appendChild(dialog);
					content.classList.remove('nobutton');
					content.classList.add('content');
					content.classList.add('fixed');
					content.style.transform = '';
					content.style.opacity = '';
					content.style.height = '';

					search.innerHTML = '搜索';
					search.addEventListener('click', function() {
						// alert(input.value); 	 input.value 是输入框里的内容
						game.tujianBegin(content, close, input.value, manual);
						input.value = "";
					});

					close.innerHTML = '关闭';
					close.addEventListener('click', function() {
						manual.remove();
						ui.arena.show();
						ui.system.show();
						//ui.menuContainer.show();			
						ui.background.style.backgroundImage = Image;
						_status.event.dialog = oldDialog;
						if (_status.event.dialog) _status.event.dialog.show();
					});

					ui.arena.classList.remove('menupaused');
					ui.arena.hide();
					ui.system.hide();
					ui.menuContainer.hide();
					ui.window.appendChild(manual);
				},
			};
			window.funcs = {
				es6: (function() {
					try {
						let a = 1;
						return true;
					} catch (e) {
						return false;
					}
				}()),
				for: function(arr, fun) {
					//arr = [node, num1, mode, num2, num] | [node, num1, num2] | [num1, num2]
					//fun = function (i, node) {} | string
					//num = undefined | '+2' | '-3' | '*6' | '/5'
					//funcs.for([0, '<=', 10, '+2'], function(i){if(i<8){console.log(i);}else{return true;}});
					//funcs.for([[1,2,3,4,5], 0 , 'length-1'], 'console.log(i)');
					//funcs.for([[6,7,8,9,10], 0 , 'length'], function(i,arr){console.log(arr[i])});
					if (!arr || !fun) return false;
					var num1, num2, node, mode, num;
					for (var str of arr) {
						var replace;
						typeof str == 'string' && str.includes && str.includes('length') && (replace = str.replace('length', ''));
						!node && node !== null && isNaN(str) && (str === null || (str && str.length && str.includes && !str.includes(
							'>') && !str.includes(
							'<') && !str.includes('='))) && (node = str);
						typeof num1 == 'number' && typeof num2 == 'number' && !num && (num = str);
						typeof num1 == 'number' && (!isNaN(str) || typeof str == 'string' && str.includes && str.includes('length')) &&
							typeof num2 !=
							'number' && (num2 = !isNaN(str) ? str : (replace ? eval(arr[0].length + replace) : arr[0].length));
						typeof num1 == 'number' && isNaN(str) && !mode && typeof str == 'string' && str.includes && !str.includes(
							'length') && (mode =
							str);
						typeof num1 != 'number' && (!isNaN(str) || typeof str == 'string' && str.includes && str.includes('length')) &&
							(num1 = !isNaN(
								str) ? str : (replace ? eval(arr[0].length + replace) : arr[0].length));
					}!mode && (mode = '<');
					!num && (num = '+1');
					var Break = false;
					for (var i = num1; eval(i + mode + num2) && !Break; !Break && eval('i=i' + num)) {
						typeof fun == 'function' && (Break = fun(i, node));
						typeof fun == 'string' && eval(fun);
					}
					return {
						arr: arr,
						fun: fun,
						variable: {
							i: i,
							node: node,
							num1: num1,
							mode: mode,
							num2: num2,
							num: num
						}
					};
				},
			};
		},
		help: {},
		config: {
			"manual": {
				"name": "点击此处进行搜索",
				"clear": true,
				onclick: function() {
					window.诗笺_manual.show();
				},
			}
		},
		package: {
			character: {
				character: {},
				translate: {},
			},
			card: {
				card: {},
				translate: {},
				list: [],
			},
			skill: {
				skill: {},
				translate: {},
			},
			intro: "“武将卡牌搜索器”的重命名版本<br>2021-05-06 更新内容：点击技能名可以查看技能代码（可复制）",
			author: "<span class='bluetext'>诗笺</span>",
			diskURL: "",
			forumURL: "",
			version: "1.2",
		},
		files: {
			"character": [],
			"card": [],
			"skill": []
		}
	}
});
