// 一些额外需要增加的一些小提示提示
interface Date {
    /** 格式化 */
    format(format:string):string;
}