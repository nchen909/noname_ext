/** 先行测试，测试用 */
declare module NonameGame {
    export var lib:Lib;
    export var status: Status;
    export var game: Game;
    export var ui: UI;
    export var get: Get;
    export var ai: AI;
}

